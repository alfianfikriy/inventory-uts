const { Supplier } = require('../models');

module.exports = {
  async createSupplier(req, res) {
    try {
      const { name, address, phone } = req.body;
      const supplier = await Supplier.create({ name, address, phone });
      res.status(201).json(supplier);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to create supplier" });
    }
  },

  async getAllSuppliers(req, res) {
    try {
      const suppliers = await Supplier.findAll();
      res.status(200).json(suppliers);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch suppliers" });
    }
  }
};