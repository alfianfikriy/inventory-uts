const { Admin } = require('../models');

module.exports = {
  async createAdmin(req, res) {
    try {
      const { username, password } = req.body;
      const admin = await Admin.create({ username, password });
      res.status(201).json(admin);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to create admin" });
    }
  },

  async getAllAdmins(req, res) {
    try {
      const admins = await Admin.findAll();
      res.status(200).json(admins);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch admins" });
    }
  }
};