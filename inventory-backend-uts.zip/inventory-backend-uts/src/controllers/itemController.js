const { Item, Category, Supplier, Admin } = require('../models');
const { Op } = require('sequelize');

module.exports = {
  async createItem(req, res) {
    try {
      const { name, stock, price, CategoryId, SupplierId, AdminId } = req.body;
      const item = await Item.create({ name, stock, price, CategoryId, SupplierId, AdminId });
      res.status(201).json(item);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to create item" });
    }
  },

  async getAllItems(req, res) {
    try {
      const items = await Item.findAll({
        include: [Category, Supplier, Admin]
      });
      res.status(200).json(items);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch items" });
    }
  },

  // Tambahan untuk laporan: ringkasan stok
  async stockSummary(req, res) {
    try {
      const items = await Item.findAll();
      const totalStock = items.reduce((sum, item) => sum + item.stock, 0);
      const totalValue = items.reduce((sum, item) => sum + (item.price * item.stock), 0);
      const averagePrice = items.length ? (totalValue / totalStock) : 0;

      res.json({ totalStock, totalValue, averagePrice });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch stock summary" });
    }
  },

  async lowStockItems(req, res) {
    try {
      const threshold = parseInt(req.query.threshold) || 5;
      const items = await Item.findAll({
        where: {
          stock: { [Op.lt]: threshold }
        }
      });
      res.json(items);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch low stock items" });
    }
  },

  async itemsByCategory(req, res) {
    try {
      const { categoryId } = req.params;
      const items = await Item.findAll({
        where: { CategoryId: categoryId },
        include: [Category]
      });
      res.json(items);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch items by category" });
    }
  },

  async categorySummary(req, res) {
    try {
      const categories = await Category.findAll({
        include: [Item]
      });

      const result = categories.map(category => {
        const totalStock = category.Items.reduce((sum, item) => sum + item.stock, 0);
        const totalValue = category.Items.reduce((sum, item) => sum + (item.price * item.stock), 0);
        const averagePrice = category.Items.length ? (totalValue / totalStock) : 0;

        return {
          category: category.name,
          totalItems: category.Items.length,
          totalStock,
          totalValue,
          averagePrice
        };
      });

      res.json(result);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch category summary" });
    }
  },

  async supplierSummary(req, res) {
    try {
      const suppliers = await Supplier.findAll({
        include: [Item]
      });

      const result = suppliers.map(supplier => {
        const totalStock = supplier.Items.reduce((sum, item) => sum + item.stock, 0);
        const totalValue = supplier.Items.reduce((sum, item) => sum + (item.price * item.stock), 0);

        return {
          supplier: supplier.name,
          totalItems: supplier.Items.length,
          totalStock,
          totalValue
        };
      });

      res.json(result);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch supplier summary" });
    }
  },

  async systemSummary(req, res) {
    try {
      const itemCount = await Item.count();
      const categoryCount = await Category.count();
      const supplierCount = await Supplier.count();
      const items = await Item.findAll();
      const totalValue = items.reduce((sum, item) => sum + (item.price * item.stock), 0);

      res.json({
        totalItems: itemCount,
        totalCategories: categoryCount,
        totalSuppliers: supplierCount,
        totalValue
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Failed to fetch system summary" });
    }
  }
};