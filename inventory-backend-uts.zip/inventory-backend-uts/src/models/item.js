'use strict';
const { Model } = require('sequelize');
module.exports = (sequelize, DataTypes) => {
  class Item extends Model {
    static associate(models) {
      Item.belongsTo(models.Category);
      Item.belongsTo(models.Supplier);
      Item.belongsTo(models.Admin);
    }
  }
  Item.init({
    name: DataTypes.STRING,
    stock: DataTypes.INTEGER,
    price: DataTypes.FLOAT,
    CategoryId: DataTypes.INTEGER,
    SupplierId: DataTypes.INTEGER,
    AdminId: DataTypes.INTEGER
  }, {
    sequelize,
    modelName: 'Item',
  });
  return Item;
};