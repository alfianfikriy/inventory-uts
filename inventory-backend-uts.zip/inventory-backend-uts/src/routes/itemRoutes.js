const express = require('express');
const router = express.Router();
const itemController = require('../controllers/itemController');

router.post('/', itemController.createItem);
router.get('/', itemController.getAllItems);

router.get('/stock-summary', itemController.stockSummary);
router.get('/low-stock', itemController.lowStockItems);
router.get('/category/:categoryId', itemController.itemsByCategory);
router.get('/category-summary', itemController.categorySummary);
router.get('/supplier-summary', itemController.supplierSummary);
router.get('/system-summary', itemController.systemSummary);

module.exports = router;